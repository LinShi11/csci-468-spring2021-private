package edu.montana.csci.csci468;

import java.util.Arrays;
import java.util.List;

public class Scratch {

    public void main(){

    }

    public void foo(int x){
        System.out.println(x);
    }
}